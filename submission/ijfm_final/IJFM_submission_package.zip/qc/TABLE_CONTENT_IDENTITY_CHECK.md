# Table content identity check

Cell-text dumps captured before and after formatting for every table.

| Document | Tables | Cell text identical |
|---|---|---|
| main manuscript | 2 | yes |
| supplement (S1–S11) | 11 | yes |
| standalone tables docx | 2 | yes |

Same table count, row count, column count, cell text, captions and
footnotes. Formatting only; all values byte-identical.
Post-check on saved files: shading cells 0, grid styles 0, vertical-border
declarations 0.
