# Phase 11 — Scientific consistency audit

Manuscript: `manuscript/manuscript_fri.docx` (rebuilt 2026-09-26).

## Introduction -> Results (every RQ answered or flagged)

- RQ1 concentration-response -> Results 3.3: 10/10 series monotone increasing,
  median rho = 1.00; scarcity of ladders stated.
- RQ2 artificial honey -> Results 3.4 + Table 2: 16/21 pairs, ratio 1.38.
- RQ3 H2O2 vs dilution -> Results 3.5 + Discussion: explicitly unresolved —
  no matched H2O2 dilution ladder with antibacterial endpoints; qualitative only.
- RQ4 catalase -> Results 3.6: median 92% residual, 13 pairs, 2 studies —
  claims qualified by study count.
- RQ5 chemistry vs label -> Results 3.7: in-sample R2 0.30 vs ~0 for label;
  grouped CV R2 negative — reported as failure to generalize, not hidden.
- RQ6 organism heterogeneity -> Results 3.7/Fig. 6/Table 1: KW significant,
  manuka vs other NS after restriction.

## Results -> Discussion (every claim maps to a result)

Checked each Discussion paragraph against analysis_results.json + tables:
mechanism reweighting is presented as "consistent with"/"compatible with";
causal language reserved for perturbation contrasts (catalase, artificial
honey, within-study ladders); cross-study correlations labelled observational;
the H2O2-MIC positive correlation is explicitly flagged as confounded;
extraction subset (103/412) declared non-representative with quantified
selection signals (see qc/extraction_selection_bias.md).

## Claim-strength uniformity

Title ("dilution-dependent ... evidence synthesis"), abstract, Results,
Discussion, Conclusions all avoid "proves/establishes/switch is demonstrated".
The word "switch" appears only to deny it ("does not establish a universal
mechanistic switch"). PASS.

## Additional checks

- No result overstated; no reported result omitted from Discussion.
- Concentration-response claims match actual series count (10 series).
- Catalase treated as perturbation evidence; residual != equated with MGO.
- Artificial honey described as imperfect comparator (text acknowledges
  "though not all").
- Chemistry-vs-label claims restricted to complete-case subset.
