# Phase 0 — Baseline Audit

Date (UTC): 2026-09-26 (updated after local project handoff)
Workspace: bougtoir/wip, branch devin/1790389165-honey-fri, dir honey-dilution-mechanisms/

## Inventory result

First pass found nothing in the VM/wip/bougtoir repos; the user then uploaded
the previously developed local workspace (`honey-dilution-review.zip`). It was
copied into `honey-dilution-mechanisms/` without overwriting the search-update
artifacts produced in this session.

## Canonical files identified

- Canonical manuscript: `manuscript/manuscript_fri.docx` (built by
  `scripts/13b_manuscript_fri.py`; legacy `manuscript.docx` = earlier
  Antibiotics-target version, kept for provenance only).
- Raw data: `data/raw/search/` (query-level raw API responses),
  `data/raw/fulltext/` (PMC OA XML, 378 files), `data/raw/search_prev_20260924/`
  (snapshot of the pre-update search responses — originals preserved, not
  overwritten by the 2026-09-26 update run).
- Interim: `data/interim/` (records, screened, eligible, extraction pools,
  per-table CSVs under `data/interim/tables/`).
- Processed: `data/processed/extraction.csv` (4,650 obs), `chemistry.csv`,
  `studies.csv`, `risk_of_bias.csv`, `data_dictionary.md`,
  `extraction_status.csv` (added this session).
- Scripts: `scripts/00_search.py` .. `17b_package_fri.py` (+ session additions
  `search_literature.py`, `build_screening.py`, `18_extraction_bias.py`).
- Analysis outputs: `results/models/analysis_results.json`,
  `results/tables/*.csv`, `results/figures/fig1-6` + graphical abstract
  (PNG/SVG/TIFF).
- References: `references/references_fri.csv` (103 Crossref-verified),
  `references_fri_context.csv`.
- Submission: `submission/fri_final/` (Fri_main_manuscript.docx, zip).
- QC: `qc/fri/01-10` audits.
- IP firewall: `private/` gitignored; `qc/fri/07_ip_firewall_scan.txt` PASS.

## What exists / is reproducible / missing

- Exists + reproducible: full pipeline `make all` re-ran end-to-end in this VM
  (see qc/reproducibility_audit.md). One Python-3.12-only f-string fixed for
  this VM's Python 3.10 (`12b_references_fri.py`); Zenodo repo-search page size
  fixed (25 max unauthenticated) in `00c_repo_search.py`.
- Missing/repaired this session: duplicate author–year in-text label pair
  (Nagy-Radványi 2024) now disambiguated 2024a/2024b; extraction-status table +
  selection-bias analysis added (`18_extraction_bias.py`).
- Author-only placeholders remain by design: author names, affiliations,
  e-mail, date (see FINAL_HANDOFF).
