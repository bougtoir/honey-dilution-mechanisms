# S11 reconciliation — 110 studies

## Newly added (rescued) studies
| PMCID | DOI | Content recovered |
|---|---|---|
| PMC13460517 | 10.1099/mic.0.001746 | UMF-graded manuka MICs vs MGO-matched controls |
| PMC9906859 | 10.1186/s12906-023-03870-8 | 20 XDR S. Typhi × 5 honeys, zones + MIC/MBC |
| PMC13315830 | 10.1155/ijfo/9085243 | 81 honeys × H. pylori MIC + H₂O₂ |
| PMC4355501 | 10.1186/s12906-015-0549-z | Pakistani honeys vs MDR S. Typhi, phenol-equiv |
| PMC3273858 | 10.3389/fmicb.2012.00036 | H₂O₂/hydroxyl mechanism rows (H₂O₂ + aw) |
| PMC10617706 | 10.1371/journal.pone.0293730 | New Caledonian honeys TPC/GOX/H₂O₂ |
| PMC10000891 | 10.3390/foods12051098 | MGO/PLA/TPC chemistry rows |

All 7 verified against Crossref metadata via `scripts/12b_references_fri.py`
(crossref-ok 110/110, zero fallbacks, zero unresolved DOIs).

## Result
- `references/references_fri.csv` now has **110 unique entries** (was 103).
- Supplementary Table S11 regenerated: 111 table rows = header + 110 studies, alphabetical.
- Every study in `data/processed/extraction.csv` (110 pmcids) maps to exactly one S11 entry; no S11 entry is absent from the dataset.
- Supplement text now reads "110 studies" everywhere relevant; remaining "103" strings are PMCID/page-number substrings only.
