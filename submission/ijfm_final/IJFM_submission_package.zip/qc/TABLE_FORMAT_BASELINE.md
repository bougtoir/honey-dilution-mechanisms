# Table format baseline (pre-conversion)

All tables used Word style "Light Grid Accent 1" (blue-accent full grid:
vertical borders, banded shading accents, internal row rules).

| Table | Rows x Cols | Style | Shading cells |
|---|---|---|---|
| main T1 (median MIC by organism) | 16 x 2 | Light Grid Accent 1 | 0* |
| main T2 (paired mechanistic contrasts) | 7 x 5 | Light Grid Accent 1 | 0* |
| supp S1–S5 | 18x5, 9x2, 20x2, 8x2, 6x2 | Light Grid Accent 1 | 0* |
| supp S6 (RoB per-study) | 111 x 9 | Light Grid Accent 1 | 0* |
| supp S7–S10 | 10x6, 5x4, 9x4, 9x4 | Light Grid Accent 1 | 0* |
| supp S11 (110 refs) | 111 x 2 | Light Grid Accent 1 | 0* |
| tables docx T1–T2 | 16x2, 7x5 | Light Grid Accent 1 | 0* |

*Shading drawn from style banding (renders as accent fill), not explicit
w:shd — removed by dropping the table style. Vertical borders and internal
rules likewise style-provided. S6/S11 are multipage → header repeat set.
