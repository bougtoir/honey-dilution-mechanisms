# Screening summary

Deduplicated records screened: 2437

- eligible: 592
- exclude_no_honey: 496
- eligible_mechanism_only: 433
- exclude_no_outcome: 268
- exclude_irrelevant: 153
- eligible_title_only: 145
- eligible_weak: 127
- eligible_dataset: 99
- review_citation_mining: 63
- exclude_topic: 61

Criteria documented in `scripts/build_screening.py` (PICOS block).
