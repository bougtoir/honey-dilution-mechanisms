# Gate 6 (final) — numerical consistency audit

All manuscript numbers are generated from analysis_results.json /
processed CSVs at build time (nothing hardcoded). Reconciled values:

- records retrieved 4,042; unique screened 2,231; eligible 412;
  extracted studies **110**; observations **5,463** — identical in
  abstract, methods, PRISMA figure, supplement, cover letter.
- concentration series 10, median rho = 1.00; pH ladder rho = −1.00.
- natural-vs-artificial pairs 25 (20 natural stronger, median ratio 1.45,
  Wilcoxon p = 0.001).
- catalase pairs 13 / 2 studies, median residual 92%.
- manuka MIC contrast 15.0% vs 18.5%, MWU p = 0.0017, LOSO ns-fraction 0.0.
- chemistry-CV: LOSO R² chem −32.32 / label −0.12 (negative; reported).
- low-RoB sensitivity: 8 studies, 512 obs, median 16.8% — updated after
  110-study rescore; consistent between §3.8, Table S9 and analysis JSON.
- reporting-quality denominators: 110 (9 low / 98 some / 3 high) in
  manuscript §3.1 and Table S6.
PASS — no undocumented numeric discrepancies.
