# Gate 3 — Data / analysis integrity audit

Date: 2026-10-13. Dataset after Gate 2 rescue: 110 studies / 5,463 rows (`data/processed/extraction.csv`; rebuild `scripts/08_build_dataset.py` → `10_analyze.py` + `10b_analyze_fri.py`).

## Provenance and rerun scope

- Rescue appended 757 rows via `scripts/21_gate2_rescue.py` from locally held full texts; sources, rationale, and skips logged in `qc/GATE2_EVIDENCE_MATURITY.md`.
- Added `organism_label` column to `manual_extraction.csv` so strain/isolate-level rows (e.g. 20 XDR S. Typhi isolates) are not collapsed by dedup — fixes a real undercount in the frozen build (previously identical-valued rows across isolates merged).
- New-control labels avoid the `mgo|umf` keyword triggers so artificial MGO-matched controls are not misflagged as Manuka/medical-grade (verified `is_artificial/is_manuka/is_medical` flags).
- Rerun: `08 → 10 → 10b`. Dependent outputs (`analysis_results.json`, summaries, `conc_response_slopes.csv`, `loo_manuka.csv`, `natural_vs_artificial_pairs.csv`, `eligibility_extraction_map.csv`) regenerated.

## Audit results

- **Concentration units**: %w/v, %v/v, %w/w kept distinct via `unit_basis`; 41.5% of MIC rows report "%" with basis unspecified — analyses run on the dominant basis with per-basis sensitivities (w/v n=375 median 15.0%; v/v n=484 median 12.5%). 8/71 MIC studies mix bases within-study — expected (honey % vs reference-compound µg/mL); no cross-basis pooling in any headline number.
- **Outcome compatibility**: no universal antibacterial score was created; MIC, MBC, zone, and perturbation fractions analysed separately.
- **Duplicates**: pipeline dedup removed 320 rows; 56 remaining identical-key rows are legitimately repeated values (same honey/organism/outcome/value reported under different `source` tables) — retained, flagged here for transparency.
- **Study dependence / pseudoreplication**: MIC rows per study median 19 (IQR 10–41, max 227, the rescued PMC13315830). Per-study medians reported alongside pooled values; within-study vs cross-study evidence kept separate (see Gate 2 grading).
- **Grouped cross-validation**: leave-one-study-out CV retained — chemistry model CV R² = −32.3 (worse than null out-of-study); honestly reported, not tuned.
- **Sensitivity analyses**: low-RoB subset (n=185, 6 studies, median 25.0%), Manuka-only/excluded, per-basis splits — all rerun post-rescue.
- **Food-relevant subgroup (new for IJFM)**: foodborne-organism subset = 1,417 MIC observations across 59 studies, median 16.0%; clinical-context subset = 1,189 / 56 studies, median 18.5% (MWU p=0.095 — potency comparable across organism provenance). Foodborne organisms: Salmonella n=681 incl. 20 XDR isolates, E. coli 816, L. monocytogenes 73, B. cereus/Bacillus 207, Vibrio, Shigella, fungi. Actual in-food-matrix validation: ~5% of studies — reported as evidence gap.
- **Censoring**: right-censored MICs (`>40%`) kept at threshold with `censor=gt` flag — convention preserved in rescued rows (PMC13460517).

## Verdict: PASS

All key numbers reproducible from stored outputs (`results/models/analysis_results.json`); analytical choices defensible; no cross-basis pooling; no central claim rests on pseudoreplication (per-study structure reported; LOO checks in place).
