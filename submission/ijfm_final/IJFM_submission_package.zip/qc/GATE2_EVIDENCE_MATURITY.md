# Gate 2 — Evidence maturity audit + targeted rescue

Date: 2026-10-13. Post-rescue dataset: **110 studies, 5,463 observations** (pre-rescue: 103 / 4,650; +7 studies, +813 rows). Rescue script: `scripts/21_gate2_rescue.py`; provenance: all sources already held locally in `data/raw/fulltext/*.xml` (no new acquisition needed; ledger unchanged).

## 1. Targeted manual rescue performed

| PMCID | What was recovered | Rows | Claim(s) strengthened |
|---|---|---|---|
| PMC13460517 | UMF 5+–20+ Mānuka MICs vs MGO+water and MGO+sugar matched controls, 4 organisms | 60 | B (artificial controls), E (MGO–MIC coupling, non-peroxide) |
| PMC9906859 | 20 XDR S. Typhi isolates × 5 honeys: zones (mm) + MIC/MBC (%v/v) | 300 | A, F (foodborne, XDR) |
| PMC13315830 | 81 honey samples × 3 H. pylori strains MIC (%v/v) + per-sample H₂O₂ (mg/mL/h) | 252 | A, C (H₂O₂ matched with MIC outcomes), F |
| PMC4355501 | Phenol-equivalence (%w/v) vs S. Typhi, 12 honey types | 12 | A, F |
| PMC3273858 | Per-honey H₂O₂ (mM/L) + water activity (buckwheat clade + Manuka) | 22 | C, E (a_w scarce) |
| PMC10617706 | 33 New Caledonian honeys: TPC, GOx, H₂O₂ (antibacterial endpoints are figure-only — not digitized; qualitative citation) | 99 | E (matched chemistry) |
| PMC10000891 | MGO, 3-PLA, GAE per honey | 12 | E (non-peroxide chemistry) |

**Deliberately skipped** (low marginal value): PMC11083411 (single correlation matrix — cited qualitatively: CAT–MIC r=0.64***); PMC9419396 (presence/absence matrix, artificial honey × EGCG — qualitative); PMC3572166 (qualitative morphology data); PMC13315830 t2 (honey+Lactobacillus *combination* — falls under the original "inseparable formulation" exclusion); PMC10051060 (MGO release kinetics from wound formulations — inseparable matrix); PMC10617706 antibacterial endpoints (figure-only; reported as limitation).

## 2. Claim-by-claim maturity grading (post-rescue)

| Claim | Evidence base | Grade |
|---|---|---|
| **A. Concentration-response** | 10 activity dilution series / 3 studies, all positive Spearman rho (median 1.0); log-log slope zone~conc = 0.33±0.55 (sub-linear); MIC medians 12.5–27.5% across organisms; new foodborne ladders (S. Typhi MIC/MBC) | **DIRECTLY SUPPORTED** for "potency rises with concentration but sub-proportionally"; the *number* of within-study ladders is still small (3 studies) |
| **B. Artificial-honey controls** | A2: 20/25 pairs natural more potent, median ratio 1.45, now spanning 8 studies incl. PMC13460517 MGO-matched controls (ratio 1.95) | **DIRECTLY SUPPORTED** that natural honey exceeds osmotic/sugar-matched controls; "artificial honey is an imperfect osmotic control" retained |
| **C. H₂O₂ across dilution** | H₂O₂ observations: 94 rows / 7+ studies (was 23); per-study H₂O₂ matched to MIC (PMC13315830); H₂O₂–MIC rho=0.46 (n=29, 2 studies, p=0.012); external anchors Bang 2003, Croatian GOx study — but **still few within-study H₂O₂×dilution ladders with matched antibacterial endpoints** | **MODERATELY SUPPORTED** — direction consistent (GOx constrained undiluted, appreciable after partial dilution); the dilution-dependence of H₂O₂ generation itself rests largely on 2–3 studies + external literature |
| **D. Catalase perturbation** | 13 pairs / 2 studies; median residual activity 0.925, 100% >50%; qualitative support PMC11083411 (CAT–MIC r=0.64*** — catalase expression, not catalase-treatment) | **DIRECTLY SUPPORTED for narrow claim** (~92% catalase-resistant activity in tested pairs, 2 studies) — but only 2 studies; heterogeneity between organisms not resolved → keep "tested pairs" framing, no generalization |
| **E. Chemistry–outcome models** | MGO–MIC rho=−0.52 (n=116, single study PMC13460517); TPC–MIC −0.15; pH–zone −0.52; a_w–MIC −0.06 (n=20); A5 regression R²=0.296 on ONE study; **LOSO-CV R² = −32.3 (worse than null out-of-study)** | **WEAK / HYPOTHESIS-GENERATING** — within-study gradients real, but chemistry does not transfer across studies; report honestly as negative CV result |
| **F. Organism heterogeneity / foodborne relevance** | Foodborne-organism subset: 1,417 MIC obs / 59 studies, median 16.0%; clinical subset 1,189/56, median 18.5% (MWU p=0.095 — comparable); Kruskal across organisms p=6.3e-35 | **DIRECTLY SUPPORTED** that susceptibility differs by organism and that foodborne organisms are well represented; actual in-food-matrix validation remains ~5% of studies → **evidence gap, stated as result** |

## 3. Impact of rescue on frozen claims

- **Manuka-vs-other contrast CHANGED**: previously "nominally lower median (15% vs 20%, p=0.011) but unstable under LOSO (38% iterations non-significant)". Post-rescue: **15.0% vs 18.5%, MWU p=0.0017, LOSO ns-fraction = 0.0** — now significant and leave-one-study-out stable. The calibrated "suggestive, not superiority" wording must be revised: a significant-but-confounded contrast (UMF grading, provenance) — upgrade to "nominally significant, not a botanical-type superiority claim" while keeping the no-superiority stance.
- MIC organism medians gained Salmonella 12.5% and H. pylori 16.67% rows; global counts updated everywhere downstream.
- Chemistry–outcome: added a strong *within-study* MGO–MIC gradient (ρ=−0.52), sharpening the contrast with the negative LOSO-CV — the "predictive chemistry does not generalize" finding is now better substantiated, not weaker.

## Verdict: PASS — with reframing

Central claims survive evidence audit **if** the paper is framed as "systematic review and quantitative evidence synthesis" (title/abstract must NOT claim a proven mechanistic transition). The mechanistic-transition narrative is the organizing hypothesis; the reportable contributions are: (i) sub-linear concentration–response, (ii) consistent superiority of natural honey over matched controls, (iii) catalase-resistant (non-peroxide) activity in tested pairs, (iv) a within-study chemistry gradient that fails out-of-study — i.e., an evidence map with quantified gaps. This matches the gate's permitted reframing and directly answers the prior "too premature" criticism by making evidence density itself a reported result.
