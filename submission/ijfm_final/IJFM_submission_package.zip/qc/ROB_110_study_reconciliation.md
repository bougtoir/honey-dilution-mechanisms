# Reporting-quality / risk-of-bias reconciliation — 110 studies

Approach A adopted: the framework (`scripts/09_dictionary_rob.py`) is fully
automated from extraction.csv + chemistry.csv, so scoring the 7 rescued
studies is defensible and was done — no scores invented.

- Assessable: **110 / 110** extracted studies.
- Rescued studies scored: all 7 (PMC13460517, PMC9906859, PMC13315830,
  PMC4355501, PMC3273858, PMC10617706, PMC10000891).
- Final ratings: **low 9, some 98, high 3** (of 110).
- Framework remains a non-validated reporting-quality proxy; described as
  such in manuscript §2.7 and Supplement S5.
- Sensitivity change: low-RoB subset is now 8 studies / 512 observations,
  median MIC 16.8% (previously smaller); qualitative pattern unchanged —
  headline result unaffected. `10_analyze.py`/`10b_analyze_fri.py` were
  rerun so all sensitivity denominators reflect the 110-study corpus.
