# Gate 7 — submission readiness

- [x] continuous line numbering present (Word `w:lnNumType`, continuous,
      start 0, countBy 1) — in IJFM_main_manuscript.docx and
      IJFM_main_manuscript_linenumbered.docx
- [x] final title identical across manuscript, supplement, cover letter,
      highlights, README-facing artifacts
- [x] S11 = exactly 110 unique studies
- [x] RoB denominator reconciled: 110/110 scored (9 low / 98 some / 3 high)
- [x] 5,463 observations reported consistently
- [x] English gate passes (GATE5_ENGLISH_AUDIT_FINAL)
- [x] IJFM scope defensible (GATE6_IJFM_SCOPE_FINAL)
- [x] figures/tables/supplement pass QC (GATE6_TABLE_FIGURE_SUPPLEMENT_FINAL)
- [x] references pass QC (GATE6_REFERENCE_FINAL)
- [x] numerical consistency passes (GATE6_NUMERICAL_CONSISTENCY_FINAL)
- [x] Gate 4–7 files exist
- [x] fresh FINAL_HANDOFF_IJFM.md exists
- [x] cover letter uses "I", opens on the scientific problem, strong close
- [x] final ZIP opens correctly (117 files)
- [x] no obsolete FRI artifacts in the final package
GO.
