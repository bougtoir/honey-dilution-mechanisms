# Table visual QA

Rendered via LibreOffice headless to PDF:
- IJFM_main_manuscript_linenumbered_FINAL.pdf — 15 pp, Tables 1–2 render
  as three-line (top/header/bottom rules only).
- IJFM_supplement_FINAL.pdf — 34 pp, S1–S11 render; S6 and S11 span
  multiple pages with repeated header rows (w:tblHeader on row 1).

Checks: no blue shading; no vertical lines; no hidden gridlines; no
clipped text or ellipsis artifacts; captions above tables; notes retained;
no table exceeds margins; no orphaned captions observed in layout text.
PASS.
