# Gate 6 — final QC (citations, figures, tables, supplement)

## Citations
- Author–year (name–date) style per IJFM Guide for Authors; 13 in-text cited context references, all emitted in the reference list; zero orphan references (reference list is generated from the USED set only).
- 110 synthesis-corpus studies carried in Supplementary Table S11 (stated in text).
- New context refs added with verified DOIs: Molan 1992 (×2, 10.1080/0005772X.1992.11099109 / …118), Brudzynski 2021 (10.1016/j.foodchem.2020.127229), Cabezas-Mera et al. 2024 (10.1002/fft2.386).

## Figures / tables
- Figs 1–6 embedded (IJFM accepts embedded figures at first submission; separate high-res PNG/TIFF/SVG also packaged) — every figure cited in text; legends standalone with abbreviation expansions.
- Tables 1–2 in manuscript + editable `IJFM_tables.docx`; both cited in text.
- Graphical abstract (PNG/TIFF/SVG) regenerated and journal-agnostic.

## Format compliance (IJFM)
- Continuous line numbering: present (`w:lnNumType`, countBy=1, continuous).
- Body length ≈3,650 words excl. references — far below 12,000 review limit.
- Author–year references; title page with placeholders; abbreviations list; ≤6 keywords; 5 highlights ≤85 chars; CRediT/COI/data-availability/funding/AI-use declarations present.
- Author placeholders retained ([Author One], [Affiliation], [E-mail]) — user fills before upload.

## Supplement
- `IJFM_supplement.docx`: S1 search strategy … S11 corpus table (11 tables); journal line updated.

## IP firewall
- grep over manuscript, supplement, cover letter, highlights: zero hits for dressing/exudate/patch/device/indicator/multilayer/wound-care terms.

**Verdict: PASS.**
