# Gate 6 (final) — figure / table / supplement QC

- Figs 1–6 exist (PNG+TIFF+SVG), embedded in manuscript, each cited in text
  in order of first appearance; legends standalone with abbreviations.
- Tables 1–2 in manuscript + editable IJFM_tables.docx, both cited.
- Supplement: S1–S11 (11 tables) internally consistent; S11 = 110 unique
  studies; no numbering gaps or duplicate numbers.
- Graphical abstract regenerated (journal-agnostic, no title text drift).
- No malformed Unicode/XML/HTML artifacts found; HTML entities stripped in
  references (e.g. `&lt;i&gt;` removed by reference builder).
- IP firewall: zero dressing/exudate/device/indicator terms across
  manuscript, supplement, cover letter, highlights.
PASS.
