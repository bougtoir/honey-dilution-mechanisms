# Gate 4 (final) — IJFM scientific reframing

- Title (final, identical across all files): "Dilution-dependent
  antibacterial activity of honey: a systematic review and quantitative
  synthesis of physicochemical and microbiological evidence"
- Abstract: result-driven, quantifies evidence density, reports in-matrix
  validation scarcity and the absent full H₂O₂ dilution ladder as findings.
- Introduction (~30% heat): honey as food ecosystem / intrinsic factors;
  novelty stated relative to Molan 1992, Brudzynski 2021, Cabezas-Mera 2024
  (dilution axis not previously synthesized); research questions (i)–(vi).
- Methods/Results: 0% heat, dry, result-first; no motivational prose.
- Discussion (~20%): separates high-confidence findings (monotone
  concentration-response; osmotic/acidic weakening), limited-perturbation
  evidence (peroxide localization, catalase residual), failed cross-study
  generalization (LOSO-CV negative), and explicit evidence gaps.
- Manuka contrast rewritten for post-rescue numbers: 15.0% vs 18.5%,
  p = 0.0017, LOSO-stable, but confounded — not a superiority claim.
- Rhetorical specs enforced: no "not merely…but", no "reweighting",
  "phenotype", "reframing", "axis" in the manuscript.
PASS.
