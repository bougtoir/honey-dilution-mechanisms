# Gate 0 — IJFM scope / article-type feasibility audit

Date: 2026-10-13. Target: *International Journal of Food Microbiology* (IJFM, Elsevier, ISSN 0168-1605; CiteScore 10.4, IF 5.2; official journal of ICFMH/IUMS).

## 1. Verified current IJFM requirements (source: Guide for Authors, ScienceDirect, accessed 2026-10-13)

- **Review articles accepted**: "Full-length original research papers, review articles … are welcomed." Reviews ≤ 12,000 words excluding references. ("Review articles may be invited by the Editor" — uninvited reviews are not prohibited; the cover letter must therefore make the scope case explicitly.)
- **Scope item directly on point**: "(1) … intrinsic and extrinsic factors affecting microbial survival and growth in foods, and food spoilage" — honey is itself a food; dilution-dependent changes in its intrinsic antibacterial factors sit inside this clause, not beside it.
- **Publication route**: hybrid/subscription journal ("Supports open access"; subscription route available — non-APC publication is possible).
- **Hard technical requirements**: continuous line numbering on all manuscripts ("If not, your paper will be sent back"); significant digits must match measurement accuracy (log microbial counts: one decimal); confidence intervals required for modelled parameters; "probiotic"/"prediction and validation" wording restrictions; poor English is grounds for rejection before review.
- **Exclusion clauses checked**: "isolation and characterization of antimicrobial substances … unless their efficacy is tested and validated in the food/beverage ecosystem" and "natural and safe antimicrobial substances … tested in real food systems" — these target original-research characterization of an antimicrobial additive. This paper is a systematic review of the intrinsic factors of a food (honey) itself, not a proposal to deploy honey as an antimicrobial in another matrix. Still, the clause raises the bar: the food-matrix validation evidence must be audited honestly (§3) and its scarcity reported as a finding, not papered over.
- **AI/data policy**: Elsevier declaration-of-generative-AI-use applies; a Research Data/Data Statement section is expected. Manuscript English quality is a stated screening criterion.

## 2. Evidence-base audit (data/processed/extraction.csv + studies.csv; n = 103 extracted studies, 4,650 observations)

| Category | Studies | Share |
|---|---|---|
| Studies testing ≥1 foodborne/food-relevant organism (E. coli, Salmonella, S. aureus, B. cereus/Bacillus, L. monocytogenes, Vibrio, Shigella, Enterobacter, Proteus, fungi, …) | 85 / 103 | 82.5% |
| Studies testing only foodborne-set organisms | 30 / 103 | 29.1% |
| Studies with explicit food-context keywords in title/table context | 15 / 103 | 14.6% |
| Studies with actual food-matrix / in-food validation mentions | ~5 / 103 | ~5% |
| Studies with wound/clinical-isolate/medical context keywords | 14 / 103 | 13.6% (552/4,650 obs ≈ 11.9%) |
| `is_medical` flagged observations | 102 obs / 4 studies | 2.2% of obs |

Outcome mix: MIC 2,378; inhibition zone 1,362; MBC 628; concentration series 84; H₂O₂ 23; a_w 10; pH 10; catalase-treated pairs 13; natural-vs-artificial pairs; MGO/TPC chemistry. The mechanistic questions (dilution → H₂O₂ onset, osmotic relief, non-peroxide factors) concern the physicochemical state of honey itself, independent of the test organism's clinical vs food origin.

## 3. Assessment against the PASS criteria

- **Review article type permitted**: yes (≤12,000 words excl. refs).
- **Meaningful food/beverage fraction OR honest reframing**: the reframing works. Honey is the food ecosystem; the review asks how dilution changes its intrinsic antimicrobial constraints (a_w, pH, H₂O₂ generation, MGO/non-peroxide factors). 82.5% of studies assay organisms of food-safety significance; major claims (dilution-dependent potency, peroxide-associated activity, catalase resistance, artificial-honey controls, chemistry–outcome coupling) do **not** depend on the 14 wound/clinical-context studies — those rows can be demoted to a context subgroup without touching any headline number.
- **Food microbiology as empirical core**: yes, with one caveat that must be stated as a result, not hidden: only ~5% of studies validate activity inside an actual food matrix; the review therefore also functions as an evidence map locating that gap — consistent with Gate 2's permitted reframing.
- **Exclusion-example resemblance**: the paper does not match the excluded categories (not a method-validation paper, not a bacteriocin survey, not an antimicrobial-additive characterization claiming in-food efficacy). The residual risk is an editor reading "honey antimicrobial = natural antimicrobial substance needing in-food validation"; mitigated by framing dilution as an intrinsic-factor question and reporting matrix-validation scarcity explicitly.

## Verdict: PASS (conditional)

Proceed to Gate 1. Conditions carried forward:

1. Reframe around "honey as a food ecosystem / intrinsic factors governing microbial survival" — NOT "honey as a wound/therapeutic antimicrobial".
2. Report food-matrix validation scarcity (~5 studies) as an explicit evidence-gap result.
3. Keep wound/clinical-context evidence as a clearly-labelled minority subgroup; no central claim may rest on it.
4. Manuscript must carry continuous line numbers; enforce IJFM significant-digit rules; retain the AI-use disclosure unchanged.
