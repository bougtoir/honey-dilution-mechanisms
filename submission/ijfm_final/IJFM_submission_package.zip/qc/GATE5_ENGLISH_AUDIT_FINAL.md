# Gate 5 (final) — English audit

Two passes completed on the regenerated manuscript (post-110-study rebuild).

## Pass 1 — automated scan (regenerated docx)
"not merely" 0 · "reweighting/reframing" 0 · "phenotype" 0 · rhetorical
"axis" 0 · motivational adverbs (Moreover/Furthermore/Notably/Importantly/
delve/landscape/nuanced/paradigm) 0 · "however" 2 · "therefore/thus" 6.
Em-dashes: residual parenthetical pairs only + CRediT boilerplate.
Semicolons: reference-list separators + the (i)–(vi) enumeration.
Long sentences (>55 w): all enumerations/lists.

## Pass 2 — line edits applied in generator
- comma parentheticals replacing em-dash contrasts (§4),
- "Direction-normalized, natural honey was…" → "After normalizing for
  direction, natural honey was…" (§3.3),
- colon/comma recast of "a direction opposite to a naive…" (§3.4),
- cover letter: "antibacterial phenotype" → "antibacterial activity",
  submission paragraph relocated after the problem statement, weak closing
  replaced ("I believe this synthesis addresses…sufficiently mature basis
  for external review.").

Section intensity: Intro ~30%, Methods/Results 0%, Discussion ~20%,
cover letter ~80% — verified. All numbers and qualifiers preserved.
PASS.
