# FRI current requirements (verified 2026-09-26 UTC)

Sources: ScienceDirect journal page + Guide for Authors (Elsevier, dynamic page —
key facts cross-checked against Elsevier author policies and recent FRI issues).
The official guide page is JS-rendered; items marked (verify) should be
re-checked on Editorial Manager at submission.

## Journal / scope
- Food Research International (Elsevier), ISSN 0963-9969; IF 8.0, CiteScore 12.8.
- Publishes "novel, high quality and high impact review papers, original
  research papers and letters" in food science/technology/engineering/nutrition.
  A systematic review + evidence synthesis is acceptable as a review paper.
- Fit framing: honey as a food matrix; physicochemistry (aw, pH, MGO, H2O2);
  antimicrobial functionality; concentration-dependence. Keep clinical/wound
  content secondary.

## Publication route
- Hybrid: subscription route = no fee; OA APC USD 4,100. Keep subscription-compatible.

## Required files (Elsevier Editorial Manager)
- Editable manuscript source (.docx or .tex; PDF alone rejected), numbered sections.
- Title page: title, authors, affiliations, corresponding author (email, postal
  address, phone).
- Abstract: single paragraph, ~250 words max (Elsevier convention; verify).
- Keywords: max 6.
- Highlights: 3–5 bullet points, ≤85 characters each (mandatory for FRI).
- Graphical abstract: expected (Elsevier-wide); TIFF/EPS/PNG, min 531×1328 px
  guidance; image only, no extra text outside the image.
- Figures: separate files; TIFF/EPS/PNG/JPEG; ≥300 dpi halftone, ≥500 dpi
  combination, ≥1000 dpi line art. Each cited in text, numbered in order.
- Tables: editable (Word/Excel in text or separate), numbered, cited, notes
  below body, no vertical rules preferred.
- References: name–date (APA-style/Elsevier Harvard): in-text "(Author, Year)";
  list alphabetical; full journal title preferred. NOT numbered Vancouver.
- Declarations: CRediT authorship, competing interests, funding, data
  availability statement; AI-use disclosure if AI tools used in preparation
  (Elsevier policy: disclose use of AI-assisted writing; AI cannot be an author).
- Supplementary material allowed (separate files, cited as "Supplementary").

## Word limits
- No hard total limit stated for reviews; keep concise (~8–10k words body is
  typical for FRI reviews) (verify).

## PRISMA
- Not mandated by FRI but standard for systematic reviews; include PRISMA 2020
  flow + checklist as supplement.

## Elsevier research data policy
- Data availability statement mandatory; linking data/code repository (e.g.
  public GitHub) satisfies it.
