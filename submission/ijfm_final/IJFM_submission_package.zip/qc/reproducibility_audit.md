# Phase 10 — Reproducibility audit (Devin VM, 2026-09-26)

Environment: Ubuntu, Python 3.10.12, `pip install -r requirements.txt`
(+ `formulaic`, `tabulate`). One VM, one workspace (per execution contract).

## What was re-run here (end-to-end)

```
make search      # 00_search.py, 00b_citation_mining.py, 00c_repo_search.py
make screen      # 01_screen.py, 02_rank_candidates.py, 04_eligibility.py
make fetch       # 03b_resolve_pmcid.py, 03_fetch_pmc.py (skips cached XML), 05_parse_tables.py
make extract     # 06_autoextract.py, 07_manual_extraction.py, 08_build_dataset.py, 09_dictionary_rob.py
make analyze     # 10_analyze.py, 10b_analyze_fri.py
make figures     # 11_figures.py, 12b_references_fri.py
make documents   # 13b_manuscript_fri.py, 14b_supplement_fri.py, 15b_fri_extras.py
make qc          # 16b_qc_fri.py (10 audit files regenerated)
make package     # 17b_package_fri.py (tables_fri.docx + Fri_submission_package.zip, 97 files)
```

All steps completed without fatal errors after two environment fixes:
1. `scripts/12b_references_fri.py` — f-string with backslash (Py≥3.12 syntax)
   rewritten for 3.10 compatibility.
2. `scripts/00c_repo_search.py` — Zenodo `size=100` exceeded the
   unauthenticated 25-row limit; set to 25.

## Results

- Search update re-executed 2026-09-26 (previous run 2026-09-24): 4,042 raw
  records; 3 net-new records vs the prior snapshot; eligible set unchanged
  (388 include + 24 review_flag = 412); extracted 103 studies, 4,650 rows.
- `qc/fri/08_reproducibility_check.txt`: 0 missing files.
- `qc/fri/02_consistency_audit.txt`: 16/16 manuscript values match
  `analysis_results.json`.

## Scope notes

- Prior raw search JSONs preserved under `data/raw/search_prev_20260924/`
  (no original overwritten); acquisition of new raw files is additive.
- PMC full-text XMLs are re-used from cache (still immutable raw inputs);
  a from-zero re-download was not repeated because the corpus is unchanged.
- Analysis uses no stochastic steps needing seeds except grouped CV, whose
  partitions are deterministic by study id.
