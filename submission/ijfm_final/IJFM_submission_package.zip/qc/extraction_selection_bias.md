# Extraction-selection bias assessment

Eligible studies: 412; quantitatively extracted: 103 (25%); not extracted: 309.

## Non-extraction reasons

- no PMC full text available: 157
- full text available but no extractable quantitative table: 131
- extracted: 103
- PMC record but full-text XML not retrievable: 21

## Extracted vs non-extracted comparisons

| comparison                       | statistic                                |     p_value |   n_extracted |   n_nonextracted |
|:---------------------------------|:-----------------------------------------|------------:|--------------:|-----------------:|
| publication year (Mann-Whitney)  | U=19778, medians 2022 vs 2020            | 0.000215233 |           103 |              309 |
| top-10 journal membership (chi2) | chi2=10.40, top10 share 0.46 vs 0.28     | 0.00126279  |           103 |              309 |
| open-access flag (chi2)          | chi2=56.63, OA share 0.69 vs 0.27        | 5.25721e-14 |           103 |              309 |
| flag f_dilution (chi2)           | chi2=0.00, f_dilution share 0.34 vs 0.33 | 0.951857    |           103 |              309 |
| flag f_mic (chi2)                | chi2=2.38, f_mic share 0.61 vs 0.52      | 0.12326     |           103 |              309 |
| flag f_peroxide (chi2)           | chi2=0.07, f_peroxide share 0.21 vs 0.23 | 0.786294    |           103 |              309 |
| flag f_osmotic (chi2)            | chi2=2.79, f_osmotic share 0.07 vs 0.14  | 0.0950154   |           103 |              309 |
| flag f_mgo (chi2)                | chi2=0.05, f_mgo share 0.17 vs 0.16      | 0.817129    |           103 |              309 |
| flag f_chem (chi2)               | chi2=7.44, f_chem share 0.91 vs 0.79     | 0.00638413  |           103 |              309 |
| flag f_zone (chi2)               | chi2=0.16, f_zone share 0.26 vs 0.24     | 0.690577    |           103 |              309 |
| flag f_orgs (chi2)               | chi2=3.56, f_orgs share 0.76 vs 0.65     | 0.0593066   |           103 |              309 |
| flag f_quant (chi2)              | chi2=0.00, f_quant share 0.83 vs 0.84    | 1           |           103 |              309 |
| flag f_manuka (chi2)             | chi2=0.16, f_manuka share 0.44 vs 0.41   | 0.686146    |           103 |              309 |
| relevance score (Mann-Whitney)   | U=19126, medians 6.5 vs 6.0              | 0.00206326  |           103 |              309 |

## Interpretation

Significant differences (p<0.05): publication year (Mann-Whitney); top-10 journal membership (chi2); open-access flag (chi2); flag f_chem (chi2); relevance score (Mann-Whitney).
The extracted subset is therefore NOT a random census of eligible studies; quantitative claims are subset-specific. This is stated in the manuscript limitations.
