# Gate 5 — English quality / humanization audit (IJFM)

Two independent passes were run on `manuscript/manuscript_ijfm.docx`
(generator `scripts/13c_manuscript_ijfm.py`).

## Pass 1 — automated pattern scan
| Pattern | Count | Verdict |
|---|---|---|
| "not merely … but …" | 0 | clean |
| "reweighting" / "reframing" / "phenotype" | 0 | clean (all removed in IJFM rewrite) |
| motivational adverbs (Moreover/Furthermore/Notably/Importantly/Interestingly/Crucially/delve/landscape/nuanced/paradigm) | 0 | clean |
| "axis" used rhetorically | 0 | clean (1 benign "concentration axis" removed) |
| em-dashes | 18 total, incl. CRediT boilerplate + parenthetical pairs | reduced; remaining are legitimate parentheticals |
| semicolons | mostly reference-list separators + the (i)–(vi) enumeration | acceptable |
| sentences >55 words | 8 | all are enumerations/lists, not run-on prose |
| LLM-symmetric triads in claims prose | none in interpretive claims | clean |
| Methods/Results tone | no motivational or interpretive prose; result-first sentences | clean |

## Pass 2 — manual line edit
Applied in the generator and rebuilt:
1. "artificial sugar-equivalent honey — an imperfect osmotic control — recapitulated" → comma parenthetical (em-dash contrast removed).
2. "Direction-normalized, natural honey was more potent" → "After normalizing for direction, natural honey was more potent".
3. "Fig. 4) — a direction opposite to a naive … expectation and most plausibly reflecting" → comma splice removed, split clauses.
4. "confounding (potent non-peroxide honeys can be low in H2O2)" → colon construction.

## Calibrated-claim check (FRI reviewer trigger list)
- No "first/novel/unprecedented/superior" claim anywhere.
- Manuka contrast now reported as nominally significant + LOSO-stable **but confounded** (UMF grading, provenance, study design); explicitly "not a botanical-type superiority claim" (§3.7, §4).
- Peroxide-dilution hypothesis labelled "supported qualitatively" + "explicit evidence gap".
- Cross-study chemistry predictability reported as a negative result.
- Every headline number reads from `analysis_results.json` / processed data; no hardcoded statistics.

**Verdict: PASS.** Manuscript reads as direct subject–verb academic English; the FRI "English quality" trigger phrases are absent.
