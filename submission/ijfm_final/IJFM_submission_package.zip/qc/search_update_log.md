# Search update log

Run UTC: 2026-09-26T02:20:52.877233+00:00

Queries (14 core + repository queries): exact strings in `scripts/search_literature.py`.

Raw records: 5441; deduplicated: 2354.

Deduplication key: DOI, else PMID, else source id.

Raw API responses: `data/raw/search/`; ledger: `data/raw/ACQUISITION_LEDGER.csv`.

## Final counts

Raw records: 5541; deduplicated: 2437.

### Records per source

- europepmc: 954
- pubmed: 693
- crossref: 538
- figshare: 149
- zenodo: 83
- dryad: 20
