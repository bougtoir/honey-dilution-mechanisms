# Author placeholder check

Unresolved placeholders intentionally retained (author fills at upload):
- IJFM_main_manuscript_linenumbered_FINAL.docx: "[Author One]",
  "[Author Two]", "[Corresponding Author]", "[Affiliation 1]",
  "[Affiliation 2]", "[email]" (title page + CRediT statement).
- IJFM_cover_letter_final.docx: "[Date]", "[Corresponding Author]",
  "[Affiliation]", "[E-mail]".
No values invented; package otherwise complete.
