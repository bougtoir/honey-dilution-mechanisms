# FRI Finishing Pass Report (2026-09-26)

Targeted polish of `manuscript/manuscript_fri.docx` per finishing-pass prompt.
Analysis frozen; all edits made in `scripts/13b_manuscript_fri.py` and
`scripts/15b_fri_extras.py`, then documents/QC/package regenerated.

## 1. Glucose oxidase wording (de-categorized)

- Intro: "glucose oxidase is inactive in undiluted honey and produces H2O2
  only after partial dilution" → "glucose oxidase activity is strongly
  constrained in undiluted honey and becomes appreciable mainly after
  partial dilution".
- Intro (hypothetical): "peroxide-mediated activity appears only at
  intermediate dilutions" → "peroxide-associated activity appears
  predominantly at intermediate dilutions".
- Results 3.4: "a peroxide mechanism that activates on dilution rather than
  at full strength" → "a peroxide contribution that is expressed
  preferentially at low concentrations rather than at full strength".
- Discussion: "partial dilution enables peroxide-associated activity" →
  "partial dilution supports peroxide-associated activity".
- Highlights and graphical abstract contained no categorical GOx wording;
  no changes required there beyond the highlight edit below.

## 2. Natural vs artificial honey interpretation (de-mechanized)

- Results 3.3: "supporting a real osmotic contribution while indicating
  additional non-osmotic activity" → "consistent with a substantial
  sugar/osmotic contribution while suggesting additional honey-specific
  effects", plus an explicit caveat that artificial honey is an imperfect
  osmotic control and residual differences may reflect multiple
  compositional differences.
- Discussion: "artificial sugar-equivalent honey recapitulated much, though
  not all, of natural honey's effect" now flags it as "an imperfect osmotic
  control".

## 3. Manuka label contrast (study-sensitivity foregrounded)

- Results 3.7 rewritten: "nominally lower median MIC ...; however, the
  contrast was unstable under leave-one-study-out resampling (38%
  non-significant). The direction is suggestive but not robust enough to
  support a general superiority claim."
- Abstract/Discussion/Conclusion/Tables/Highlights audited: no general
  Manuka-superiority claim remains anywhere.

## 4. Reference / Supplement consistency (regenerated audit)

- 10 in-text citations, 10 bibliography entries; cited-but-missing: none;
  uncited bibliography entries: 0; duplicate intext labels: 0.
- All 103 extracted-study refs Crossref-verified; Supplementary Table S11
  contains 103 study rows; the manuscript statement is true.

## 5. Figure/table order and cross-references

- Fig first-appearance order 1→6 PASS; Tables 1→2 PASS; 6 embedded images;
  captions and panel references unchanged (no numbering defects found).

## 6. Encoding / character cleanup

- DOCX text + highlights.txt scanned for control chars, soft hyphens, BOM,
  PUA, full-width forms, XML/HTML entities, HTML tags, LaTeX: all clean.
  Only intended typographic characters (em/en dash, curly quotes) present.

## 7. Claim-calibration cross-check

- H2O2 dilution evidence still described as sparse/qualitative; no
  universal mechanistic switch claimed; catalase limited to 13 pairs /
  2 studies; chemistry-vs-label reported as within-study informative but
  non-transferable; artificial honey treated as imperfect comparator;
  Manuka described as study-sensitive. AI-use disclosure untouched.

## 8. Numerical consistency

- 16/16 audit checks PASS (02_consistency_audit.txt): 4,042 / 2,231 /
  412 / 103 / 4,650; 10 series / 3 studies; rho=1.00; 16 of 21, ratio 1.38,
  p=0.005; +0.6 mm; catalase 92% (13 pairs, 2 studies); H2O2 rho 0.46
  n=29; MGO rho −0.52 n=116; CV R² −32.32; organism medians; Manuka
  15% vs 20%, p=0.011; LOSO 38% non-significant; years 2022 vs 2020.

## Outputs

- `submission/fri_final/Fri_main_manuscript.docx` (inline figures retained)
- `submission/fri_final/Fri_submission_package.zip` regenerated (99 files)
- QC reports regenerated under `qc/fri/` (all PASS)

## Final checklist

[x] all items in the finishing-pass checklist confirmed; AI-use disclosure
unchanged; final DOCX valid (python-docx reopen OK, 6 inline images).
