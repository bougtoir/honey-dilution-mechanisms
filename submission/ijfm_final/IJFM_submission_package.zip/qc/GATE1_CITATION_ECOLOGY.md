# Gate 1 — Citation ecology audit (IJFM retarget)

Date: 2026-10-13. See `GATE1_CLOSEST_PRIOR_STUDIES.csv` for the 10-study comparison table.

## Closest prior work — summary

The closest prior literature splits into three non-overlapping groups:

- **Mechanism narratives**: Molan 1992 (osmotic/peroxide/non-peroxide taxonomy), Brudzynski 2021 (GOx–H2O2 chemistry). Neither quantitatively pools antibacterial outcomes.
- **Single-lab dilution studies**: Bang et al. 2003 (H2O2 peaks at 30–50% v/v), Willix et al. 1992 (manuka-vs-other dilution MICs). Directly about dilution but n-of-one-lab, no synthesis.
- **Potency reviews/meta-analyses**: medical-grade honey MIC meta-analysis 2025 (pooled MIC 10.8% w/v; clinical isolates), Nolan et al. 2020 (clinical SR), Cabezas-Mera et al. 2024 (stingless-bee honey MA incl. foodborne pathogens). These pool potency; none models the dilution axis or couples chemistry to outcome.

**No prior review or meta-analysis answers the same question**: a cross-study quantitative synthesis of how antibacterial mechanism shifts along the dilution axis, with machine-extracted data (103 studies / 4,650 observations), chemistry–outcome coupling, and perturbation (catalase, artificial-honey control) evidence grading. Novelty boundary is defensible.

## Already-cited ecology (references_fri.csv + context refs)

Present and load-bearing: Willix 1992; Bang 2003; Kwakman 2010 + 2011; Cooper 1999; the 103 extracted primary studies incl. PMC3389331 (buckwheat concentration-dependence), PMC8021062 (non-peroxide Malaysian honey), PMC6881396 (H2O2 antibiofilm), PMC8209695 (H2O2 production factors).

## Candidate additions for the IJFM rewrite (each tied to a concrete use)

| Citation | Used to support | Section |
|---|---|---|
| Molan PC (1992) Bee World 73 | Origin of the osmotic/peroxide/non-peroxide framework the review tests quantitatively | Introduction |
| Brudzynski K (2021) Food Chem 335:127395 | GOx–H2O2 imbalance; colloidal suppression of GOx in undiluted honey (mechanistic basis for the dilution claim) | Introduction, Discussion |
| Cabezas-Mera FS et al. (2024) Food Frontiers 5:964-93 | Closest competing MA (stingless honey, foodborne+clinical); boundary for novelty statement | Introduction, Discussion |
| Medical-grade honey SR+MA (2025; pooled MIC 10.8% w/v) | MIC-pooling precedent; contrast: clinical scope, no mechanism axis | Discussion |
| IJFM honey-microbiota review (2026) | IJFM neighborhood: honey as food ecosystem with resident microbes | Introduction |
| Strelec/GOx Croatian honeys dilution study (2018, via hrcak.srce.hr) | Second independent dilution–H2O2 inverted-U observation (if not already extracted — verify before citing; must not be a duplicate of dataset rows) | Results/Discussion |

IJFM papers are cited because they carry the claim, not because they are IJFM. No IJFM citation added solely for ecology signalling.

## Verdict: PASS

Defensible novelty boundary; no prior review/meta-analysis answers the same question; Introduction and Discussion can be wired to the closest prior literature per the table above.
