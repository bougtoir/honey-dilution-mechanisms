# FINAL HANDOFF — Honey dilution antibacterial mechanisms (FRI)

Date: 2026-09-26 UTC · One VM, one canonical tree (`wip/honey-dilution-mechanisms/`)

## Final manuscript
- Title: "Dilution-dependent antibacterial mechanisms of honey: a systematic
  review and cross-study quantitative evidence synthesis"
- Target journal: Food Research International (Elsevier, hybrid/subscription
  route; author–date references; 6 keywords; highlights ≤85 chars; TIFF ≥500 dpi)

## Counts (generated, audit-verified)
- Records identified: 4,042 → screened 2,231 → eligible 412
  (388 include + 24 review-flag) → quantitatively extracted 103 studies,
  4,650 observations.
- Key analyses: concentration-response (10/10 series positive, rho=1.00);
  natural vs artificial (16/21 pairs, ratio 1.38, p=0.005); catalase residual
  92% (13 pairs, 2 studies); chemistry-vs-label grouped CV negative
  (no cross-study prediction); organism heterogeneity (KW p<0.001);
  extraction-selection bias quantified.

## Major limitations (stated in manuscript)
- Catalase evidence from 2 studies; no matched H2O2-dilution-ladder dataset
  (RQ3 qualitative only — key evidence gap).
- Extracted subset (103/412) skews recent/open-access — quantified.
- Automated extraction residual error; rule-based RoB is a proxy;
  no prospective registration.

## Claim calibration
"consistent with / supports a model / compatible with" throughout; no
universal-switch claim; causal language restricted to perturbation contrasts.

## Status
- Reproducibility: full `make` pipeline re-run end-to-end in this VM — PASS
  (qc/reproducibility_audit.md; qc/fri/08: 0 missing).
- Reference audit: 103/103 Crossref-verified; duplicate author-year fixed
  (qc/fri/06).
- Numerical consistency: 16/16 manuscript values match analysis results
  (qc/fri/02).
- Fabrication: 100% row provenance, 0 missing source XML (qc/fri/01).
- IP firewall: PASS (qc/fri/07); `private/` gitignored, not in package.
- Formatting: no LaTeX/HTML residue; placeholders = author fields only.

## Final artifacts
- `submission/fri_final/Fri_main_manuscript.docx`
- `submission/fri_final/Fri_submission_package.zip` (99 files, ~8.4 MB —
  includes cover letter, highlights, graphical abstract, supplement, tables,
  figures PNG+TIFF, data/code archive)

## Author-only placeholders to complete before submission
- `[Author One]`, `[Author Two]`, `[Corresponding Author]`, affiliations,
  e-mail, cover-letter date/address; CRediT roles currently generic —
  adjust to actual contributions.
