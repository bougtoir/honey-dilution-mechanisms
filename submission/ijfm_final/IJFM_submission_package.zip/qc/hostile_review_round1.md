# Phase 7 — Hostile review, round 1 (Devin VM, 2026-09-26)

Manuscript under review: `manuscript/manuscript_fri.docx` (post-update rebuild).

## Reviewer A — FRI handling editor
- Scope fit: acceptable — food functionality/food microbiology framing; honey as
  antimicrobial food matrix; wound/clinical content is absent from title and
  minimal in text. PASS.
- Desk-rejection risks found and FIXED this round:
  1. Keywords were 7; Elsevier maximum is 6 — trimmed (dropped "antibacterial
     activity", already implied by title).
  2. TIFF figures exported at 300 dpi; Elsevier combination-art minimum is
     500 dpi — all TIFF exports raised to 500 dpi in `11_figures.py` and
     `15b_fri_extras.py` and regenerated.
  3. Duplicate author–year in-text labels (two Nagy-Radványi 2024 papers) —
     disambiguated 2024a/2024b in `12b_references_fri.py`.
- Remaining author-only placeholders (names, affiliations, e-mail, ORCID,
  date) are unavoidable and listed in FINAL_HANDOFF.

## Reviewer B — food microbiology
- MIC/MBC/zone outcomes analyzed separately (no arbitrary pooled score). PASS.
- Percent bases (% w/v vs % v/v) analyzed separately and the manuscript
  explicitly warns they are not interchangeable (medians 15% vs 8%). PASS.
- Organism analyses are organism-level with Gram grouping secondary. PASS.
- Weakness: inoculum size/media heterogeneity limits pooling — already stated
  as a limitation; no further data available. Documented.

## Reviewer C — food chemistry
- aw, pH, H2O2, MGO, moisture analyzed only where measured comparably;
  ecological cross-study correlations flagged as observational and the
  positive H2O2–MIC correlation is explicitly called confounded. PASS.
- Grouped leave-one-study-out CV (R2 = -32 chemistry / -33 label) is reported
  honestly rather than suppressed. Strong.

## Reviewer D — quantitative synthesis/statistics
- No meta-analytic pooling across incompatible bases — appropriate choice,
  stated.
- Spearman summaries + paired contrasts (Wilcoxon/sign) + grouped CV —
  appropriate to sparse heterogeneous data.
- Publication-bias statistics NOT run (assumptions unmet) — correct.
- Extraction-selection bias quantified this session (18_extraction_bias.py):
  extracted subset skews recent (2022 vs 2020, p=2.2e-4), open-access
  (69% vs 27%, p=5e-14), higher-score and chemistry-reporting studies;
  mechanistic flags (dilution, MIC, peroxide, MGO) are balanced. Manuscript
  limitation already states subset is non-representative. PASS.

## Implemented corrections this round
1. Keywords 7 -> 6.
2. TIFF 300 -> 500 dpi (all 7 figures incl. graphical abstract).
3. Author–year label disambiguation (2024a/2024b).
4. New `data/processed/extraction_status.csv`,
   `results/tables/extracted_vs_nonextracted.csv`,
   `qc/extraction_selection_bias.md` (Phase 2 deliverables).

## Not fixable without new data (documented, claims calibrated)
- Catalase evidence: 2 studies (stated).
- No matched H2O2 dilution ladder (stated as the key evidence gap).
- 103/412 extraction coverage with quantified selection — stated.
- RoB instrument unvalidated — stated; domain-level reporting used.
