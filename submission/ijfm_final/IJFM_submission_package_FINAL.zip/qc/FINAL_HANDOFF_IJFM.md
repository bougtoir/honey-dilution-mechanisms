# FINAL HANDOFF — IJFM submission package (Gate 7: GO)

## Decision: GO for International Journal of Food Microbiology

All seven gates passed (Gate 0 conditional-PASS with carried conditions,
all discharged). Fallback journals (Journal of Food Science → JSFA) not
needed.

## What changed vs the FRI version
- Title: "Dilution-dependent antibacterial activity of honey: a systematic
  review and quantitative synthesis of physicochemical and microbiological
  evidence" (no "mechanisms" claim).
- Reframed to honey-as-food-ecosystem / intrinsic factors; wound/clinical
  evidence demoted to context; food-relevance argued from the organism mix
  (~82% of studies test foodborne organisms).
- Dataset rescued post-Gate 2: **110 studies / 5,463 observations**
  (was 103/4,650). Recovery: UMF-graded MGO controls, XDR S. Typhi panel,
  81-honey H. pylori panel, H₂O₂/a_w/MGO/TPC chemistry rows
  (`scripts/21_gate2_rescue.py`).
- Manuka-vs-other MIC contrast materially strengthened post-rescue:
  15.0% vs 18.5%, MWU p=0.0017, LOSO non-significant fraction 0.0 —
  reported as nominally significant but confounded, NOT a superiority claim.
- AI-pattern prose removed; em-dash contrasts reduced; "not merely…but",
  "reweighting", "phenotype", "reframing" eliminated.
- Continuous line numbering added (IJFM requirement); author–year
  references confirmed correct for IJFM; abbreviations list added;
  in-matrix-validation scarcity reported as an explicit result.
- Cover letter rewritten in single-author "I" voice; IJFM fit argued on
  intrinsic-factor/food-preservation grounds; no mention of FRI.

## Package (submission/ijfm_final/)
- IJFM_main_manuscript.docx (line-numbered, ~3,650 words excl. refs)
- IJFM_cover_letter.docx, IJFM_highlights.txt
- figures/ (PNG+TIFF+SVG incl. graphical abstract)
- supplement/ (supplement_ijfm.docx, tables_ijfm.docx, highlights_ijfm.docx)
- data_code/ (extraction/chemistry/studies/rob/dictionary CSVs, logs,
  references CSVs, results JSON+tables, all scripts, env files)
- IJFM_submission_package.zip (116 files, 7.5 MB, verified)

## Rebuild
    python3 scripts/08_build_dataset.py
    python3 scripts/10_analyze.py && python3 scripts/10b_analyze_fri.py
    python3 scripts/11_figures.py
    python3 scripts/13c_manuscript_ijfm.py
    python3 scripts/14c_supplement_ijfm.py
    python3 scripts/15c_ijfm_extras.py
    python3 scripts/17c_package_ijfm.py

## Before uploading — author actions
- Fill [Author]/[Affiliation]/[E-mail]/[Date] placeholders.
- Editorial Manager: article type "Review article"; attach manuscript,
  highlights, figures separately, supplement as supplementary material.
- No APC if publishing via the subscription route (hybrid open access is
  optional; not required).

## QC trail
qc/GATE0_IJFM_SCOPE.md, GATE1_CLOSEST_PRIOR_STUDIES.csv,
GATE1_CITATION_ECOLOGY.md, GATE2_EVIDENCE_MATURITY.md,
GATE3_ANALYSIS_INTEGRITY.md, GATE5_ENGLISH_AUDIT.md, GATE6_FINAL_QC.md
