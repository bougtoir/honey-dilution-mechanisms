# Dilution-Dependent Antibacterial Mechanisms of Honey

A systematic review and cross-study quantitative evidence synthesis of published
in vitro data on how honey's antibacterial mechanisms vary with dilution.

## Reproduction

Requires Python 3.12+ with the packages in `requirements.txt`
(`pip install -r requirements.txt`) or the conda spec in `environment.yml`.

Run in order (or `make all`):

| script | purpose |
|---|---|
| `scripts/00_search.py` | reproducible searches of PubMed, Europe PMC, Crossref; raw JSON kept in `data/raw/search/` |
| `scripts/00b_citation_mining.py` | backward citation mining via Europe PMC |
| `scripts/01_screen.py` | deduplication + stage-1 title/abstract screening |
| `scripts/02_rank_candidates.py` | mechanistic-candidate ranking |
| `scripts/03_fetch_pmc.py` | PMC open-access full-text (JATS XML) retrieval |
| `scripts/03b_resolve_pmcid.py` | DOI-to-PMCID resolution for additional eligible records |
| `scripts/04_eligibility.py` | rule-based eligibility classification |
| `scripts/05_parse_tables.py` | table extraction from XML (colspan expansion, nested tables) |
| `scripts/06_autoextract.py` | rule-based extraction of outcome, chemistry and dilution-series tables |
| `scripts/07_manual_extraction.py` | manually curated mechanistic extractions |
| `scripts/08_build_dataset.py` | harmonized analysis dataset + chemistry + studies tables |
| `scripts/09_dictionary_rob.py` | data dictionary + structured risk-of-bias assessment |
| `scripts/10_analyze.py` | all quantitative analyses; writes `results/models/` and `results/tables/` |
| `scripts/11_figures.py` | figures (PNG + TIFF, 300 dpi) |
| `scripts/12_references.py` | numbered reference list + integrity audit |
| `scripts/13_manuscript.py` | manuscript DOCX |
| `scripts/14_supplement.py` | supplement DOCX |
| `scripts/15_cover_letter.py` | cover letter DOCX |
| `scripts/16_qc.py` | QC audits (fabrication, formatting, reproducibility, language) |
| `scripts/17_package.py` | submission ZIP assembly |

## Outputs

- `manuscript/manuscript.docx`, `manuscript/supplement.docx`, `manuscript/cover_letter.docx`
- `data/processed/extraction.csv` — observation-level dataset (5,026 rows) with
  table/row/column provenance and extraction method flags
- `data/processed/chemistry.csv` — honey-level physicochemical data
- `data/processed/risk_of_bias.csv`, `data/processed/data_dictionary.md`
- `results/models/analysis_results.json`, `analysis_summary.txt`
- `results/tables/` — per-analysis result tables
- `results/figures/` — figures as PNG and TIFF
- `qc/` — audit reports
- `submission/` — final ZIP archive

## Evidence scope

All data derive from previously published public sources retrieved through
public APIs. No new experiments were performed. Where planned analyses were not
estimable from public data (e.g., dilution-resolved H2O2 paired with
antibacterial endpoints), the limitation is documented rather than filled with
fabricated values.
